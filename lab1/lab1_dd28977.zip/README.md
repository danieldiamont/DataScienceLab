# Lab 1
## By Daniel Diamont

View the Lab_1_dd28977.ipynb for code, plots, and discussion.

View the Lab1_Written_dd28977.pdf for the written portion of the lab.
